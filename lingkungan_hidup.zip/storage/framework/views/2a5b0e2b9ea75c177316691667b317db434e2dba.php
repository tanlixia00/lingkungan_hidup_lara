

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Daftar Riwayat</div>
                
                <div class="card-body">
                
                
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


                    
                    <table id="nota" class="table table-hover table-condensed">
                        <thead>
                        <tr>
                            <th style="width:10%">Kode</th>
                            <th style="width:30%">Waktu Transaksi</th>
                            <th style="width:30%" class="">Total</th>
                            <th style="width:10%"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td data-th="Kode" name='id'>
                                   #<?php echo e($t->id); ?>

                                </td>
                                <td data-th="waktu"><?php echo e($t->created_at); ?></td>
                                <td data-th="Total">
                                   Rp.<?php echo e($t->total_belanja); ?>

                                </td>
                                
                                <td>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(url('view-detail-order', $t->id)); ?>"> View</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\uaswfp\resources\views/frontend/riwayat.blade.php ENDPATH**/ ?>