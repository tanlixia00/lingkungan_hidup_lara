

<?php $__env->startSection('title', 'Daftar Pengaduan'); ?>


<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-13">
            <div class="card">
                <div class="card-header">Daftar Pengaduan</div>

                   
                    
                    <table id="nota" class="table table-hover table-condensed">
                        <thead>
                        <tr>
                            <!-- <th style="width:5%">ID</th> -->
                            <th style="width:20%">gambar</th>
                            <th style="width:25%">alasan</th>
                            <th style="width:20%">lokasi</th>
                            <th style="width:10%">tanggal</th>
                            <th style="width:10%">telp</th>
                            <th style="width:10%">status</th>
                            
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <!-- <td data-th="Kode">
                                   <?php echo e($t->id); ?>

                                </td> -->
                                <td data-th="Kategori">
                                <img src="<?php echo e(asset('images/'.$t->gambar)); ?>" width="250" height="250">
                                <img src="<?php echo e($t->gambar); ?>" width="250" height="250">
                                </td>
                                <td data-th="Kode">
                                   <?php echo e($t->alasan); ?>

                                </td>
                                <td data-th="">
                                    <?php echo e($t->lokasi_satwa); ?>

                                </td>
                                <td data-th="tanggal">
                                    <?php echo e($t->tanggal); ?>

                                </td>
                                <td data-th="tanggal">
                                    <?php echo e($t->telepon); ?>

                                </td>
                                <td>
                                <?php echo e($t->status); ?>


                                </td>
                            
                                <!-- <td class="actions" data-th="">
                                <form method='POST' action="<?php echo e(url('frontend/'.$t->id )); ?>" >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type='submit' value='hapus' class='btn btn-xs btn-danger'
                                    onclick="if(!confirm('apakah anda yakin?')) return false;"/>
                                </form>
                                </td> -->
                            
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\ling_hidup\resources\views/pengaduan/listPengaduan.blade.php ENDPATH**/ ?>