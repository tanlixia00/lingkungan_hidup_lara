

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
<?php endif; ?>

    <div class="container products">

        <div class="row">

            <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-18 col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <!-- <img src="<?php echo e(asset('images/'.$product->gambar)); ?>" width="500" height="250"> -->
                        <img src="<?php echo e($product->gambar); ?>" width="250" height="250">    
                        <div class="caption">
                            <h5><?php echo e(Str::limit($product->nama, 20)); ?></h5>
                            <p><?php echo e(Str::limit(strtolower($product->spesies), 50)); ?></p>


                            <p class="btn-holder"><a href="<?php echo e(url('/satwadetail'.$product->idSatwa)); ?>" 
                               class="btn btn-warning btn-block text-center btn-disable" role="button">Detail</a> </p>


                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div><!-- End row -->

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\ling_hidup\resources\views/frontend/index.blade.php ENDPATH**/ ?>