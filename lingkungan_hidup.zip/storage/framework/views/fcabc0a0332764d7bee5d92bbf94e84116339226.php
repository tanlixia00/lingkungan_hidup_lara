

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Form Kategori Baru</div>
                
                <div class="card-body">
                <a href="<?php echo e(route('books.index')); ?>"><< Kembali</a>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                <hr/>
                    <form method="POST" action="<?php echo e(route('category.store')); ?>">
                        <div class="form-group">
                                <?php echo csrf_field(); ?>
                            <label>Nama Kategori</label>
                            <input type="text" class="form-control" name="namaCategory">
                            <small class="form-text text-muted">Isikan Kategori Anda</small>
                            <br/>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                   

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\uaswfp\resources\views/kategori/createform.blade.php ENDPATH**/ ?>