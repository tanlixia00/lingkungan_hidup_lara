

<?php $__env->startSection('title', 'Lokasi Wisata'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Lokasi Konservasi</div>
                
                <div class="card-body">

                    
                    <table id="nota" class="table table-hover table-condensed">
                        <thead>
                        <tr>
                            <th style="width:10%">Kode</th>
                            <th style="width:20%">Nama Lokasi</th>
                            <th style="width:60%">Alamat Lengkap</th>
                            <th style="width:10%">Link</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td data-th="Kode">
                                   <?php echo e($t->id); ?>

                                </td>
                                <td data-th="Kategori">
                                    <?php echo e($t->nama_lokasi); ?>

                                </td>
                                <td data-th="Kategori">
                                    <?php echo e($t->alamat); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e($t->link); ?>">maps</a>
                                <!-- <input type='submit' value='hapus' class='btn btn-xs btn-danger'/> -->
                                </td>
                                
                            
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\ling_hidup\resources\views/lokasi_wisata/index.blade.php ENDPATH**/ ?>