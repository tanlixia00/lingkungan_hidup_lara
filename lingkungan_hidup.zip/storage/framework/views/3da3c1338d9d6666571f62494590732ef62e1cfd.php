

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Form Edit Buku</div>
                
                <div class="card-body">
                <a href="<?php echo e(route('books.index')); ?>"><< Kembali</a>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                <hr/>
                    <form method="POST" action="<?php echo e(route('books.update', $data->id)); ?>" enctype="multipart/form-data">
                        <div class="form-group">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("PUT"); ?>
                            <label>Judul Buku</label>
                            <input type="text" class="form-control" name="namaBuku" value="<?php echo e($data->title); ?>">
                            <small class="form-text text-muted">Isikan Judul Buku Anda</small>
                            <br/>
                            <label>Publisher </label>
                            <input type="text" class="form-control" name="publisherBuku" value="<?php echo e($data->publisher); ?>">
                            <small class="form-text text-muted">Isikan Nama Badan Publisher Anda</small>

                            <br/>
                            <label>Harga Jual Buku </label>
                            <input type="number" class="form-control" name="hargaBuku" value="<?php echo e($data->price); ?>">
                            <small class="form-text text-muted">Isikan Nominal Harga Buku Anda</small>

                            <br/>
                            <label>Kategori Buku</label> <br>
                            <select name="kategori" id="spls">
                                <?php $__currentLoopData = $kat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($data->idKategori == $s->id ): ?>
                                        <option value="<?php echo e($s->id); ?>" selected><?php echo e($s->name); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
                                    <?php endif; ?>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <br>
                            <br/>
                            <label>Stok Buku </label>
                            <input type="number" class="form-control" name="stok" value="<?php echo e($data->stok); ?>">
                            <small class="form-text text-muted">Isikan Jumlah Stok Buku</small>
                            
                            <br/>
                            <div>
                                <img src="<?php echo e(asset('images/'.$data->gambar)); ?>" alt="Current image" width="200">
                            </div>
                            

                            <br/>
                            <label>Image Input</label> <br>
                            <input type="file" id="exampleInputFile1" name="image_upload">
                            <small class="form-text text-muted">berisi foto buku</small>
                            <br/>

                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\uaswfp\resources\views/book/editform.blade.php ENDPATH**/ ?>