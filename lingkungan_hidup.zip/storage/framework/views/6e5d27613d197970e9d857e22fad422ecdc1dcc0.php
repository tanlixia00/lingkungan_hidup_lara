

<?php $__env->startSection('title', 'Cart'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Confirmation</h1>
    <table id="cart" class="table table-hover table-condensed">
        <thead>
        <tr>
            <th style="width:50%">Product</th>
            <th style="width:10%">Price</th>
            <th style="width:8%">Quantity</th>
            <th style="width:22%" class="text-center">Subtotal</th>
            <th style="width:10%"></th>
        </tr>
        </thead>
        <tbody>

        <?php $total = 0 ?>
        
        <?php if(session('cart')): ?>
            <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $total += $details['price'] * $details['quantity'] ?>
                <tr>
                    <td data-th="Product">
                        <div class="row">
                            <div class="col-sm-3 hidden-xs"><img src="<?php echo e(asset('images/'.$details['gambar'])); ?>"  height="150" 
                                class="img-responsive"/></div>
                            <div class="col-sm-9">
                                <h4 class="nomargin"><?php echo e($details['name']); ?></h4>
                            </div>
                        </div>
                    </td>
                    <td data-th="Price">Rp. <?php echo e($details['price']); ?></td>
                    <td data-th="Quantity"><?php echo e($details['quantity']); ?> </td>
                    <td data-th="Subtotal" class="text-center">Rp. <?php echo e($details['price'] * $details['quantity']); ?></td>
                    <td class="actions" data-th="">
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        </tbody>
        <tfoot>
        <tr class="visible-xs">
            <td class="text-center"><strong>Total <?php echo e($total); ?></strong></td>
        </tr>
        <tr>
            <td><a href="<?php echo e(url('/')); ?>" class="btn btn-warning"><i class="fa fa-angle-left"></i> Continue Shopping</a></td>
            <td class="hidden-xs"></td>
            <td class="hidden-xs"><a href="<?php echo e(url('/submit_checkout')); ?>" class="btn btn-danger"> Finish 
                <i class="fa fa-angle-right"></i> </a></td>
            <td class="hidden-xs text-center"><strong>Total Rp. <?php echo e($total); ?></strong></td>
        </tr>
        </tfoot>
    </table>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\uaswfp\resources\views/frontend/checkout.blade.php ENDPATH**/ ?>