

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Daftar Buku</div>
                
                <div class="card-body">
                <a href="<?php echo e(route('books.create')); ?>">+ Tambah Buku Baru</a>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


                    
                    <table id="nota" class="table table-hover table-condensed">
                        <thead>
                        <tr>
                            <th style="width:10%">Kode</th>
                            <th style="width:30%">Nama Buku</th>
                            <th style="width:30%" class="text-center">Publisher</th>
                            <th style="width:20%" class="text-center">Harga</th>
                            <th style="width:10%"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td data-th="Kode">
                                   <?php echo e($t->id); ?>

                                </td>
                                <td data-th="Judul"><?php echo e($t->title); ?></td>
                                <td data-th="Total">
                                    Rp. <?php echo e($t->publisher); ?>

                                </td>
                                <td data-th="Harga">
                                    Rp. <?php echo e($t->price); ?>

                                </td>

                                <td class="actions" data-th="">
                                    <a class="btn btn-info btn-sm update-cart" data-id="<?php echo e($t->id); ?>" 
                                        href="<?php echo e(route ('book.show',$t->id)); ?> ">View</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uaswfp\resources\views/book/index.blade.php ENDPATH**/ ?>