

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Daftar Kategori</div>
                <div> <a href="<?php echo e(route('books.index')); ?>">go to Book</a> </div>
                
                <div class="card-body">
                <a href="<?php echo e(route('category.create')); ?>">+ Tambah Kategori Baru</a>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <table id="nota" class="table table-hover table-condensed">
                        <thead>
                        <tr>
                            <th style="width:10%">Kode</th>
                            <th style="width:30%">Nama Kategori</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td data-th="Kode">
                                   <?php echo e($t->id); ?>

                                </td>
                                <td data-th="Kategori"><?php echo e($t->name); ?></td>
                                
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-permission', $t)): ?>
                                <td class="actions" data-th="">
                                <form method='POST' action="<?php echo e(url('category/'.$t->id )); ?>" >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type='submit' value='hapus' class='btn btn-xs btn-danger'
                                    onclick="if(!confirm('apakah anda yakin?')) return false;"/>
                                </form>
                                </td>
                            <?php endif; ?>
                                <td>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('category.edit', $t->id)); ?>"> Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\uaswfp\resources\views/kategori/index.blade.php ENDPATH**/ ?>