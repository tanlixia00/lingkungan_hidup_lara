

<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container products">

        <div class="row">

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-18 col-sm-6 col-md-3">
                    <div class="thumbnail">
                        <img src="<?php echo e(asset('images/'.$product->gambar)); ?>" width="500" height="300">
                        <div class="caption">
                            <h4><?php echo e($product->nama_produk); ?></h4>
                            <p><?php echo e(Str::limit(strtolower($product->deskripsi), 50)); ?></p>
                            <p><strong>Price: </strong> Rp. <?php echo e($product->harga_produk); ?></p>
                            <p class="btn-holder"><a href="<?php echo e(url('add-to-cart/'.$product->id)); ?>" 
                               class="btn btn-warning btn-block text-center" role="button">Add to cart</a> </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div><!-- End row -->

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uaswfp\resources\views/frontend/index.blade.php ENDPATH**/ ?>