

<?php $__env->startSection('title', 'Daftar'); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Daftar Satwa</div>

                   
                    
                    <table id="nota" class="table table-hover table-condensed">
                        <thead>
                        <tr>
                            <th style="width:5%">ID</th>
                            <th style="width:30%">gambar</th>
                            <th style="width:15%">Nama</th>
                            <th style="width:10%">Spesies</th>
                            <th style="width:10%">Asal</th>
                            <th style="width:30%">Deskripsi</th>
                            
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td data-th="Kode">
                                   <?php echo e($t->idSatwa); ?>

                                </td>
                                <td data-th="Kategori">
                                <!-- <img src="<?php echo e(asset('images/'.$t->gambar)); ?>" width="250" height="250"> -->
                                <img src="<?php echo e($t->gambar); ?>" width="250" height="250">    
                                </td>
                                <td data-th="Kode">
                                   <?php echo e($t->nama); ?>

                                </td>
                                <td data-th="Kategori">
                                    <?php echo e($t->spesies); ?>

                                </td>
                                <td data-th="Kode">
                                   <?php echo e($t->asal); ?>

                                </td>
                                <td data-th="Kategori">
                                    <?php echo e($t->deskripsi); ?>

                                </td>
                                
                                
                            
                                <td class="actions" data-th="">
                                <form method='POST' action="<?php echo e(url('satwa/'.$t->idSatwa )); ?>" >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type='submit' value='hapus' class='btn btn-xs btn-danger'
                                    onclick="if(!confirm('apakah anda yakin?')) return false;"/>
                                </form>
                                </td>
                            
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\ling_hidup\resources\views/satwa/listSatwa.blade.php ENDPATH**/ ?>