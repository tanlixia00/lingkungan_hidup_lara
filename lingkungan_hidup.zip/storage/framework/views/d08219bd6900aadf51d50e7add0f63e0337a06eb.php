

<?php $__env->startSection('title', 'Detail Satwa'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="page-bar">
    
    <!-- nama, stok, harga jual, harga produksi -->
    </div>
        <form role="" method="post" action="" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-body">
                <div>
                    <!-- <label for="inputfile">Gambar Satwa</label> <br> -->
                    <img src="<?php echo e(asset('images/'.$data->gambar)); ?>" alt="Current image" height="300" width="300" >
                    <br>
                </div>
                <br>
                <div class="form-group">
                    <label>Nama Satwa</label>
                    <input type="text" class="form-control" name="namaSatwa" id="namaSatwa" placeholder="" value="<?php echo e($data->nama); ?>" readonly >
                    <span class="help-block">
                     </span>
                </div>
                
                
                <div class="form-group">
                    <label>Spesies</label>
                    <input type="text" class="form-control" id="spesies" name="spesies" placeholder="total stok"  value="<?php echo e($data->spesies); ?>" readonly >
                </div>
                <div class="form-group">
                    <label>Asal</label>
                    <input type="text" class="form-control" id="asal" name="asal" placeholder="berisi asal"  value="<?php echo e($data->asal); ?>" readonly >
                </div>
                <div class="form-group">
                    <label>Deskripsi</label> <br>
                    <textarea disabled name="desc" id="desc" cols="140" rows="5" value=""><?php echo e($data->deskripsi); ?></textarea>
                </div>
                
            </div>
        </form>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\ling_hidup\resources\views/frontend/detail.blade.php ENDPATH**/ ?>