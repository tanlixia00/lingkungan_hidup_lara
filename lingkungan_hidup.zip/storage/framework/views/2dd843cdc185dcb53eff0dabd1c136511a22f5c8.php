

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Form Buku Baru</div>
                
                <div class="card-body">
                <a href="<?php echo e(route('books.index')); ?>"><< Kembali</a>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                <hr/>
                    <form method="POST" action="<?php echo e(route('books.store')); ?>" enctype="multipart/form-data">
                        <div class="form-group">
                                <?php echo csrf_field(); ?>
                            <label>Judul Buku</label>
                            <input type="text" class="form-control" name="namaBuku">
                            <small class="form-text text-muted">Isikan Judul Buku Anda</small>
                            <br/>
                            <label>Publisher </label>
                            <input type="text" class="form-control" name="publisherBuku">
                            <small class="form-text text-muted">Isikan Nama Badan Publisher Anda</small>

                            <br/>
                            <label>Harga Jual Buku </label>
                            <input type="number" class="form-control" name="hargaBuku">
                            <small class="form-text text-muted">Isikan Nominal Harga Buku Anda</small>

                            <br/>
                            <label>Kategori Buku</label> <br>
                            <select name="kategori" id="spls">
                                <?php $__currentLoopData = $categori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s->id); ?>"> <?php echo $s->name ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <br>
                            <br/>
                            <label>Stok Buku </label>
                            <input type="number" class="form-control" name="stok">
                            <small class="form-text text-muted">Isikan Jumlah Stok Buku</small>

                            <div class="form-group">
                                <label for="inputfile">Image input</label>
                                <input type="file" id="exampleInputFile1" name="image_upload">
                                <p class="help-block">
                                    berisi foto produk
                                </p>
                            </div>
                        </div>  
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                   

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\uaswfp\resources\views/book/createform.blade.php ENDPATH**/ ?>