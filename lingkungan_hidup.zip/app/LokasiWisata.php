<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LokasiWisata extends Model
{
    protected $table = "lokasi_wisata"; 
    public $timestamps = false;
}
