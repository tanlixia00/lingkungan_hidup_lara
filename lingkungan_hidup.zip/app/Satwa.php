<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Satwa extends Model
{
    protected $table = "satwa"; 
    protected $primaryKey = "idSatwa";
    public $timestamps = false;
}
